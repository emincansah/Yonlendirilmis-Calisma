﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection baglanti = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security=True");
        public MainWindow()
        {
            InitializeComponent();
        }

        private void girisbtn_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                baglanti.Open();
                string Sql = "Select * From Login where kullaniciAdi=@kullanıcıad   AND sifre=@sifresi";

                SqlParameter PRM1 = new SqlParameter("kullanıcıad", kullanıcıtxtx.Text.Trim());
                SqlParameter PRM2 = new SqlParameter("sifresi", sifretxtbx.Text.Trim());
                SqlCommand komut = new SqlCommand(Sql, baglanti);
                komut.Parameters.Add(PRM1);
                komut.Parameters.Add(PRM2);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(komut);
                da.Fill(dt);
                if (servisrdbtn.IsChecked==true&& dt.Rows.Count>0)
                {
                    KayıtGrd.Visibility = Visibility.Visible;
                    yedekparcaGrd.Visibility = Visibility.Collapsed;
                    loginGrd.Visibility = Visibility.Collapsed;
                
                }
             

               
               
              else if (yedekRdbtn.IsChecked == true && dt.Rows.Count > 0)
                {
               
                    KayıtGrd.Visibility = Visibility.Collapsed;
                    yedekparcaGrd.Visibility = Visibility.Visible;
                    loginGrd.Visibility = Visibility.Collapsed;
                }
            }
            catch (Exception)
            {


                MessageBox.Show("Hatalı Giriş");
            }
            
      
        }

        private void yedekgeriBtn_Click(object sender, RoutedEventArgs e)
        {
            yedekparcaGrd.Visibility = Visibility.Collapsed;
            KayıtGrd.Visibility = Visibility.Collapsed;
            loginGrd.Visibility = Visibility.Visible;
            sifretxtbx.Text = "";
            kullanıcıtxtx.Text = "";
            baglanti.Close();
        }

        private void servisGeriBtn_Click(object sender, RoutedEventArgs e)
        {
            yedekparcaGrd.Visibility = Visibility.Collapsed;
            KayıtGrd.Visibility = Visibility.Collapsed;
            loginGrd.Visibility = Visibility.Visible;
            sifretxtbx.Text = "";
            kullanıcıtxtx.Text = "";
            baglanti.Close();
        }



      private void KayıtBtn_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
