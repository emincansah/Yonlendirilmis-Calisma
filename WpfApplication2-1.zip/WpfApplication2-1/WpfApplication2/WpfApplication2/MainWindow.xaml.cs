﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Data.OleDb;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection baglanti = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security = True");
        public MainWindow()
        {
            InitializeComponent();
           
        }
        class OgrenciProvider
        {
            SqlConnection con;
            SqlCommand cmd;

            public OgrenciProvider() //Kurucu metotta bağlantı yolumuzu belirledik.
            {
                con = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Database1.mdf;Integrated Security = True");
            }

            public List<kullanıcıclass> Kullanıcıgetir()
            {
                List<kullanıcıclass> Kullanıcıliste = new List<kullanıcıclass>();
                string sql = "SELECT *FROM Login";
                con.Open();
                cmd = new SqlCommand(sql, con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    kullanıcıclass ogr = new kullanıcıclass();
                    ogr.Id = Convert.ToInt32(dr[0]);
                    ogr.kullaniciAdi = dr[1].ToString();
                    ogr.sifre= dr[2].ToString();
          
                    Kullanıcıliste.Add(ogr);
                }
                con.Close();
                return Kullanıcıliste;
            }
        }
        private void girisbtn_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                baglanti.Open();
                string Sql = "Select * From Login where kullaniciAdi=@kullanıcıad   AND sifre=@sifresi";

                SqlParameter PRM1 = new SqlParameter("kullanıcıad", kullanıcıtxtx.Text.Trim());
                SqlParameter PRM2 = new SqlParameter("sifresi", sifretxtbx.Text.Trim());
                SqlCommand komut = new SqlCommand(Sql, baglanti);
                komut.Parameters.Add(PRM1);
                komut.Parameters.Add(PRM2);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(komut);
                da.Fill(dt);
                if (servisrdbtn.IsChecked == true && dt.Rows.Count > 0)
                {
                    KayıtGrd.Visibility = Visibility.Visible;
                    yedekparcaGrd.Visibility = Visibility.Collapsed;
                    loginGrd.Visibility = Visibility.Collapsed;

                }

             
                else if (yedekRdbtn.IsChecked == true && dt.Rows.Count > 0)
                {

                    KayıtGrd.Visibility = Visibility.Collapsed;
                    yedekparcaGrd.Visibility = Visibility.Visible;
                    loginGrd.Visibility = Visibility.Collapsed;
                }
                else
                {
                    MessageBox.Show("Hatalı Giriş");
                }
                baglanti.Close();

            }
            catch (Exception)
            {


                MessageBox.Show("Hatalı Kod");
            }


        }

        private void yedekgeriBtn_Click(object sender, RoutedEventArgs e)
        {
            yedekparcaGrd.Visibility = Visibility.Collapsed;
            KayıtGrd.Visibility = Visibility.Collapsed;
            loginGrd.Visibility = Visibility.Visible;
            sifretxtbx.Text = "";
            kullanıcıtxtx.Text = "";
            baglanti.Close();
        }

        private void servisGeriBtn_Click(object sender, RoutedEventArgs e)
        {
            yedekparcaGrd.Visibility = Visibility.Collapsed;
            KayıtGrd.Visibility = Visibility.Collapsed;
            loginGrd.Visibility = Visibility.Visible;
            sifretxtbx.Text = "";
            kullanıcıtxtx.Text = "";
            baglanti.Close();
        }



        private void KayıtBtn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            yntloginGrd.Visibility = Visibility.Collapsed;
            kullanıcısilGrd.Visibility = Visibility.Collapsed;
            kullanıcıkytGrd.Visibility = Visibility.Collapsed;
            KayıtGrd.Visibility = Visibility.Collapsed;
            yedekparcaGrd.Visibility = Visibility.Collapsed;
            loginGrd.Visibility = Visibility.Visible;
            baglanti.Close();
            yntsifretxtbx.Text = "";
            yntkullanıcıtxtx.Text = "";

        }

        private void yntgirisbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                baglanti.Open();
                string Sql1 = "Select * From Yonetici where yoneticiadı=@kullanıcıadı   AND yoneticisifre=@sifresini";

                SqlParameter PRM3 = new SqlParameter("kullanıcıadı", yntkullanıcıtxtx.Text.Trim());
                SqlParameter PRM4 = new SqlParameter("sifresini", yntsifretxtbx.Text.Trim());
                SqlCommand komut = new SqlCommand(Sql1, baglanti);
                komut.Parameters.Add(PRM3);
                komut.Parameters.Add(PRM4);
                DataTable dq = new DataTable();
                SqlDataAdapter db = new SqlDataAdapter(komut);
                db.Fill(dq);
                if (yntservisrdbtn.IsChecked == true && dq.Rows.Count > 0)
                {
                    yntloginGrd.Visibility = Visibility.Collapsed;
                    kullanıcısilGrd.Visibility = Visibility.Collapsed;
                    kullanıcıkytGrd.Visibility = Visibility.Visible;
                    KayıtGrd.Visibility = Visibility.Collapsed;
                    yedekparcaGrd.Visibility = Visibility.Collapsed;
                    loginGrd.Visibility = Visibility.Collapsed;

                }

                else if (yntyedekRdbtn.IsChecked == true && dq.Rows.Count > 0)
                {yntloginGrd.Visibility = Visibility.Collapsed;
                    kullanıcıkytGrd.Visibility = Visibility.Collapsed;
                    kullanıcısilGrd.Visibility = Visibility.Visible;
                    KayıtGrd.Visibility = Visibility.Collapsed;
                    yedekparcaGrd.Visibility = Visibility.Collapsed;
                    loginGrd.Visibility = Visibility.Collapsed;
                    baglanti.Open();
                    OgrenciProvider op = new OgrenciProvider();
                    dg1.ItemsSource = op.Kullanıcıgetir();

           
                    
                }
                else
                {
                    MessageBox.Show("Hatalı Giriş");
                }
                baglanti.Close();
            }
            catch (Exception)
            {


                MessageBox.Show("Hatalı Kod");
            }


        }

        private void yonetisayfabtn_Click(object sender, RoutedEventArgs e)
        {
            
                yntloginGrd.Visibility = Visibility.Visible;
                kullanıcıkytGrd.Visibility = Visibility.Collapsed;
                kullanıcısilGrd.Visibility = Visibility.Collapsed;
                KayıtGrd.Visibility = Visibility.Collapsed;
                yedekparcaGrd.Visibility = Visibility.Collapsed;
                loginGrd.Visibility = Visibility.Collapsed;
            }

        private void kullanıcıkayıtbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
                    baglanti.Open();

                string kullanıcıad = kullanıcıkyttxtx.Text;
                string klncısifre = sifrekyttxtbx.Text;
                string Sql2 = "insert into Login(kullaniciAdi,sifre) values ('"+ kullanıcıad+"','"+ klncısifre +"')";
                SqlCommand komutsatırı = new SqlCommand(Sql2 , baglanti);
                komutsatırı.ExecuteNonQuery();
                baglanti.Close();
             
                MessageBox.Show("Müşteri Kayıt İşlemi Gerçekleşti.");
            }
            catch (Exception)
            {
                MessageBox.Show("İşlem Sırasında Hata Oluştu." );
            }

        }

        private void listviev_SourceUpdated(object sender, DataTransferEventArgs e)
        {

        }
    }
}
