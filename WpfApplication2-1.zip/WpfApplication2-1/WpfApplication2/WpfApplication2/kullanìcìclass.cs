﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication2
{
    class kullanıcıclass
    {
        int _id;
        string _kullanıcı;
        string _sifre;

       

        public int Id
        {
            get
            {
                return _id;
            }

            set
            {
                _id = value;
            }
        }

        public string kullaniciAdi
        {
            get
            {
                return _kullanıcı;
            }

            set
            {
                _kullanıcı = value;
            }
        }

        public string sifre
        {
            get
            {
                return _sifre;
            }

            set
            {
                _sifre = value;
            }
        }
    }
}
